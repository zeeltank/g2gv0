# Ramp Lab: a physics simulation to copy

A baseball rolls down a wooden plank that rests on a steel drum, drops to the floor and knocks over a traffic cone. This is the sample for **physics with real models**: every thing in the picture is a downloaded 3D model, the floor is a real material (colour, bumps, shininess and crevices), and the shapes that collide are the shapes of the models. Open it in the Create screen, play it, then change one thing at a time. (The other sample, Pendulum Lab, shows a simulation built from equations.)

In free play the world is **live**: press Launch, or grab the ball with the mouse, drag it, and let go to throw it. The missions use the worked-out run, which is the same every time.

## What is in the folder

| File | What it is |
|---|---|
| `simulation.json` | The simulation: controls, the physical world, the pictures and the lesson. This is the file you edit. |
| `manifest.json` | The model and picture files you use, with who made each one, its licence and where it came from. |
| `assets/` | The files themselves: five 3D models (`.glb`), four pictures that make one floor material, and a sky. Only files listed in `manifest.json` belong here. |
| `recipe.json` | How the files in `assets/` were made from the downloaded originals (a size for each picture; the plank turned level). Not needed to run it. |

## The parts that are new

- **engine**: `"rigid"` means bodies and physics instead of equations.
- **world.bodies**: the floor (a `box`), the drum (a `cylinder`), the plank (a `box` as long and as wide as the real plank), the ball (a `ball`), and the cone and the chest, whose shape is `{"kind":"hull","asset":"cone"}`: **the shape of the downloaded model itself**. The `events` entry `hit` notes the first time the ball touches the cone.
- **Where the plank lies** is worked out from the *angle* knob in `model.derived`: its low end is on the floor and its underside rests on the rim of the drum, so tilting the ramp slides the plank along the floor.
- **views[0].objects**: each object has a `body`, so it stands where that body is and turns as it turns. `offset` moves a model against its body (the plank's picture is lower than the middle of its box).
- **scenes[0].ground**: a floor from a material library: colour (`texture`), `normal` (bumps), `rough` (shininess), `ao` (crevices), `tile` (metres per tile). **scenes[0].light** sets the sun, the fill light, the sky's light and the tone curve.
- **What is recorded**: for every body `b`, `b_x b_y b_z`, `b_vx b_vy b_vz`, `b_speed`, `b_rx b_ry b_rz` and the orientation `b_qx b_qy b_qz b_qw`.

## Change these first

1. `id`, `title`, `subtitle`, `summary` in `simulation.json`. The `id` must be new: lowercase letters, digits, `-` and `_`.
2. The knob ranges and defaults, the ball's `mass` and `radius`, and `gap` (how far beyond the plank the cone stands).
3. The mission goals and the `reference` angle that solves it (the checker proves it works and that the start does not).
4. To swap a model, replace the file in `assets/` and its entry in `manifest.json`. Look at its size and where its origin is first: a model's origin is wherever its maker left it.

## Licences

Four of the five models and all the pictures are CC0 (no conditions). The wooden plank is CC BY 3.0 by Justin Randall: its credit must stay with it, and the Create screen asks you to confirm you may use each file. Keep the licence and credit of every file you add in `manifest.json`.
