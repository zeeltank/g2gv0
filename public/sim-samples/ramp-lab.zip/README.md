# Ramp Lab: a physics simulation to copy

A ball rolls down a ramp and has to reach a goal zone. This is the sample for **physics**: the ball, the ramp and the goal are *bodies* in a small world, and the runtime works out how they move. Open it in the Create screen, play it, then change one thing at a time. (The other sample, Pendulum Lab, shows a simulation built from equations.)

## What is in the folder

| File | What it is |
|---|---|
| `simulation.json` | The simulation: controls, the physical world, the pictures and the lesson. This is the file you edit. |
| `manifest.json` | The model and picture files you use, with who made each one and its licence. |
| `assets/` | The files themselves: two 3D models (`.glb`) and two pictures (`.jpg`). Only files listed in `manifest.json` belong here. |

## The parts that are new

- **engine**: `"rigid"` means bodies and physics instead of equations.
- **world**: gravity, the `materials` (how grippy and how bouncy), and the `bodies`: the floor and the ramp (`fixed`: they never move), the ball (`dynamic`: pushed by gravity and contacts) and the goal zone (a `sensor`: it does not push, it only notices the ball). Every number can use your controls, so the *angle* knob tilts the ramp and the *grip* knob changes the friction.
- **world.events**: `goal` is noted the first time the ball enters the goal zone. Missions and outputs read it as `goal.count` and `goal.1.t` (the time).
- **What is recorded**: for every body `b`, the run records `b_x b_y b_z` (place), `b_vx b_vy b_vz` (velocity), `b_speed` and `b_rx b_ry b_rz` (turning). The ball in the 3D picture follows `ball_x`, `ball_y`, `ball_z`.
- **flow**: `intro`, an `info` page (text to read), `play` (free play), a `mission` and a `quiz`. Steps can come in any order and you can add more.

## Change these first

1. `id`, `title`, `subtitle`, `summary` in `simulation.json`. The `id` must be new: lowercase letters, digits, `-` and `_`.
2. The knob defaults, the ramp's `half` length (in `model.constants`) and the ball's `mass` and `radius`.
3. The mission goals and the `reference` angle that solves it (the checker proves it works and that the start does not).

## Licences

All four files are CC0 (no conditions). Keep the licence and credit of every file you add in `manifest.json`: the Create screen asks you to confirm you may use each file.
