# Pendulum Lab: your first simulation

This folder is a complete, working simulation. It is also the template you copy to make your own.
Open the sample in the Create screen first and play it. Then change one thing at a time.

## What is in the folder

| File | What it is |
|---|---|
| `simulation.json` | The simulation itself: the controls, the equations, the pictures and the lesson. This is the file you edit. |
| `manifest.json` | A list of the model and picture files you use, with who made each one and under which licence. |
| `assets/` | The files themselves: three 3D models (`.glb`) and one picture (`.jpg`). Only files listed in `manifest.json` belong here. |
| `README.md` | This note. It is optional and you can delete it. |

## The parts of `simulation.json`, in plain words

- **title, subtitle, summary, meta**: the name and the short description shown on the card. Change these first.
- **knobs**: the controls the learner moves. Here: string length, start angle, the world (Earth, Moon, Mars), bob mass and friction.
- **model**: the physics. `derived` works out gravity from the world; `state` lists what changes in time (the angle, the turning speed and the bob's place); `ode` says how fast each one changes; `events` notes each time the bob passes the lowest point; `outputs` are the numbers read off a finished swing, such as "Time of one swing".
- **charts**: the two graphs under the picture (angle and energy against time).
- **assets**: the 3D models and pictures used, each with a short name (`pad`, `bob`, `block`, `sky`). The file itself is named in `manifest.json`. You never write the file's `sha256` by hand: the Create screen fills it in.
- **views**: how a swing is drawn. The first is the 3D picture (a pad, a post and beam, a bob that follows the equations, a string drawn as a line, a click-to-read label on the pad). The second is a flat side view with an arrow for the speed. The first one listed opens first.
- **flow**: the lesson, step by step: `intro`, `play` (free play), `predict`, two `mission` steps and `explain` (the closing questions). Each mission has goals, a start, and a `reference` answer that the checker uses to prove the mission can be solved.

## Change these first

1. `title`, `subtitle`, `summary` and the author name in `meta`.
2. The words of the `intro` step and of the two missions.
3. One number in a mission: for example the target time of mission 1 (`1.45` and `1.55` in the goal, `0.56` in `reference`). After changing a goal, upload again: the checker tells you if the mission can no longer be solved, or already passes at the start.
4. The 3D models: replace a file in `assets/` and update its line in `manifest.json` (name, credit, source). Only use files you have the right to use, and write the licence honestly.

## Rules the checker enforces

- Every name must be unique and written with lowercase letters, digits, `-` or `_`.
- Every mission must be solvable by its `reference`, and must not already pass at its `start`.
- A 3D picture needs at least one model in `assets`.
- Every file in `manifest.json` needs a licence, a credit and a source.

See `AUTHORING.md` for every key, with its limits and an example.
